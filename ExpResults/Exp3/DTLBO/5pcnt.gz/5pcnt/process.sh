#!/bin/bash
ecj_data_processing() {
  filesStat=(
  job.0.out.stat job.1.out.stat job.2.out.stat job.3.out.stat job.4.out.stat
  job.5.out.stat job.6.out.stat job.7.out.stat job.8.out.stat job.9.out.stat
  job.10.out.stat job.11.out.stat job.12.out.stat job.13.out.stat job.14.out.stat
  job.15.out.stat job.16.out.stat job.17.out.stat job.18.out.stat job.19.out.stat
  job.20.out.stat job.21.out.stat job.22.out.stat job.23.out.stat job.24.out.stat
  job.25.out.stat job.26.out.stat job.27.out.stat job.28.out.stat job.29.out.stat)
  for i in ./${filesStat[*]}
    do
     cut -f3 -d ' ' $i > ./$i.bstonly  
     #-f says which field you want to extract, -d says what is the field delimeter that is used in the input file 
    done
  ls -v job.*.out.stat.bstonly | xargs paste > result.bst.all 
  rm *.bstonly
}
ecj_data_processing
