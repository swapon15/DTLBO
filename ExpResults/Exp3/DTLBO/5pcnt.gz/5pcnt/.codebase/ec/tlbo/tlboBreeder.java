package ec.tlbo;
import java.util.ArrayList;
import java.util.Random;
import ec.*;
import ec.util.*;
import ec.vector.*;
import ec.simple.*;
/**
 * 
 * Breeds the individual for teacher and learner phase
 *
 */
public class tlboBreeder extends Breeder {
	    
	public static Population previousPopulation ;  
	public int[] bestSoFarIndex;
	private MersenneTwisterFast mtf;
	
	public tlboBreeder() {
		previousPopulation = null;
		bestSoFarIndex = null;
	}

	public void setup(final EvolutionState state, final Parameter base) { return;}
	public void prepareTLBOBreeder(EvolutionState state) {

		if( bestSoFarIndex == null || state.population.subpops.length != bestSoFarIndex.length )
			bestSoFarIndex = new int[state.population.subpops.length];

		for( int subpop = 0 ; subpop < state.population.subpops.length ; subpop++ ) {
			Individual[] inds = state.population.subpops[subpop].individuals;
			bestSoFarIndex[subpop] = 0;
			
			for( int j = 1 ; j < inds.length ; j++ )
				if( inds[j].fitness.betterThan(inds[bestSoFarIndex[subpop]].fitness) )
					bestSoFarIndex[subpop] = j;
		}
	}
	
	public int getTeacherIndex(EvolutionState state, Population oldPopulation) {
		/** find out the teacher individual***/		
		
		Individual [] inds = oldPopulation.subpops[0].individuals;
		Individual teacher =  inds[0];
	    int i = 1, tIndex = -1;			
		for (; i < inds.length; i++) 		  
		  if (((SimpleFitness)teacher.fitness).fitness() < ((SimpleFitness)inds[i].fitness).fitness()) {
			  teacher = inds[i];
			  tIndex = i;
		  }
		return tIndex;		
	}
	
	private Individual getTeacher(EvolutionState state, Population oldPopulation) {
		/** find out the teacher individual***/		
		
		Individual [] inds = oldPopulation.subpops[0].individuals;
		Individual teacher =  inds[0];
				
		for (int i = 1; i < inds.length; i++) 		  
		  if (((SimpleFitness)teacher.fitness).fitness() < ((SimpleFitness)inds[i].fitness).fitness()) 
			  teacher = inds[i];      		
		return teacher;		
	}
	
	private Individual teacherPhase (EvolutionState state, Population oldPopulation, int idx, Individual teacher, double[] mean, int tF, int genomeLength) {
		Individual ind = (Individual)oldPopulation.subpops[0].individuals[idx].clone();
		Individual myCopy = (Individual)oldPopulation.subpops[0].individuals[idx];
		for (int x = 0; x < genomeLength; x++) 
			((DoubleVectorIndividual)ind).genome[x] += mtf.nextDouble() * (((DoubleVectorIndividual)teacher).genome[x] - tF * mean[x]);
		
		if (!valid((DoubleVectorIndividual)ind)) return myCopy;
				
		return ind;
	}
	
	private Individual learnerPhase(EvolutionState state, Population oldPopulation, int idx,  int genomeLength) {
		int popSize = oldPopulation.subpops[0].individuals.length;
		int peerId = mtf.nextInt(popSize);
		Individual me = (Individual)oldPopulation.subpops[0].individuals[idx].clone();
		Individual myCopy = (Individual)oldPopulation.subpops[0].individuals[idx];
		Individual peer = oldPopulation.subpops[0].individuals[peerId];
				
		if (((SimpleFitness)me.fitness).fitness() > ((SimpleFitness)peer.fitness).fitness()) {
			for (int x = 0; x < genomeLength; x++) {
				 double rand = mtf.nextDouble();    
				((DoubleVectorIndividual)me).genome[x] +=  rand * (((DoubleVectorIndividual)me).genome[x] - ((DoubleVectorIndividual)peer).genome[x]);				
			}			
		}
		else {
			for (int x = 0; x < genomeLength; x++) {
				 double rand = mtf.nextDouble();    
				((DoubleVectorIndividual)me).genome[x] += rand * (((DoubleVectorIndividual)peer).genome[x] - ((DoubleVectorIndividual)me).genome[x]);				
			}
		}
		if (!valid((DoubleVectorIndividual)me)) return myCopy;
		return me;
	}
	private double[] getMean(Population oldPopulation, int genomeLength) {
		
	    double [] mean = new double[genomeLength];
	    int popSize = oldPopulation.subpops[0].individuals.length;
		for (int gene = 0; gene < genomeLength; gene++) {
			double sum = 0;
			for (int i = 0; i < popSize ; i++) {
				DoubleVectorIndividual ind = (DoubleVectorIndividual)oldPopulation.subpops[0].individuals[i];
				sum += ((DoubleVectorIndividual)ind).genome[gene];
			}
			mean[gene] = sum/(popSize*1.0);
		}
		return mean;
	}
	
    public Population breedPopulation(EvolutionState state) { return null;    }
	public Population breedPopulation(EvolutionState state, int whichPhase) {
		
		prepareTLBOBreeder(state);		
		mtf = state.random[0];
		Population oldPopulation = state.population;
		previousPopulation = oldPopulation; // old population		
		Individual teacher = getTeacher(state, oldPopulation);
		int k = getTeacherIndex(state, oldPopulation);
		DoubleVectorIndividual t = (DoubleVectorIndividual) teacher;
		
		int genomeLength = ((DoubleVectorIndividual)teacher).genomeLength();
		double [] meanByDimension = new double[genomeLength];
		meanByDimension = getMean(oldPopulation, genomeLength);
		
		Population newpop = (Population) state.population.emptyClone();
										
		if (whichPhase == 0) { //teacher phase			
			int tFactor = mtf.nextInt(2) + 1;			
			for( int i = 0 ; i < newpop.subpops[0].individuals.length ; i++ ) {
				//if (!(popIndex.contains(i)))
					newpop.subpops[0].individuals[i] = teacherPhase (state, oldPopulation, i, teacher, meanByDimension, tFactor, genomeLength);
				//else 
				//	newpop.subpops[0].individuals[i] = oldPopulation.subpops[0].individuals[i]; // these individuals are random immigrants
			}	 
		}
		else { // learner phase
			for( int i = 0 ; i < newpop.subpops[0].individuals.length ; i++ ) {
				//if (!(popIndex.contains(i)))
					newpop.subpops[0].individuals[i] = learnerPhase ( state, oldPopulation, i,  genomeLength);
				//else 	
				//	newpop.subpops[0].individuals[i] = oldPopulation.subpops[0].individuals[i]; // these individuals are random immigrants
			}		
		}			
		
		return newpop;
	}

	public boolean valid(DoubleVectorIndividual ind) {
		return (ind.isInRange());
	}
}
