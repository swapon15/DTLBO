/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package ec.app.coevolve1;

import ec.simple.SimpleFitness;
import ec.coevolve.*;
import ec.*;
import ec.vector.*;
import java.util.*;
import java.util.Arrays;
import java.lang.*;
import java.util.Random;

public class ig extends Problem implements GroupedProblemForm
    {
    private static int count ;
    private double NOISE_INTENSITY = 1.0;
    Random r;
    public ig() {
	count = 0;
	r = new Random();
    }	
    public void preprocessPopulation(final EvolutionState state, Population pop, boolean[] updateFitness, boolean countVictoriesOnly)
    //updateFitness is assessFitness in the Evaluator. assesFitness' are set to true before calling preprocessPopulation
    // If you put style == SINGLE_ELIINATION.. in the Evaluator then countVictoriesOnly is true otherwise false 
        {
	
        for( int i = 0 ; i < pop.subpops.length ; i++ )
            if (updateFitness[i])
                for( int j = 0 ; j < pop.subpops[i].individuals.length ; j++ ) {
                    ((SimpleFitness)(pop.subpops[i].individuals[j].fitness)).trials = new ArrayList();
		    //System.out.println(((SimpleFitness)(pop.subpops[i].individuals[j].fitness)).trials.size());	
		}
        }

    public void postprocessPopulation(final EvolutionState state, Population pop, boolean[] updateFitness, boolean countVictoriesOnly)
        {
	System.out.println("Counter: " +count);
        for( int i = 0 ; i < pop.subpops.length ; i++ )
            if (updateFitness[i])
                for( int j = 0 ; j < pop.subpops[i].individuals.length ; j++ )
                    {
                    SimpleFitness fit = ((SimpleFitness)(pop.subpops[i].individuals[j].fitness));
		     IntegerVectorIndividual temp;
                     temp = (IntegerVectorIndividual)pop.subpops[i].individuals[j];
		     int hash = (Arrays.hashCode( temp.genome  ) & 0x7FFFFFFF) % 100;
                     System.out.print("Post Hash: " +hash + "  Its trial arraylist : ");
                    // average of the trials we got
                    int len = fit.trials.size();
                    double sum = 0;
                    for(int l = 0; l < len; l++) {
                        sum += ((Double)(fit.trials.get(l))).doubleValue();
			System.out.print(((Double)(fit.trials.get(l))).doubleValue() + " , ");
		    }
                    sum /= len;
                                                                        
                    // we'll not bother declaring the ideal
                    fit.setFitness(state, sum, false);
                    pop.subpops[i].individuals[j].evaluated = true;
		    System.out.println("  Its fitness after post : " +sum);
		    System.out.println();
                    }
        }

    public void evaluate(final EvolutionState state,
        final Individual[] ind,  // the individuals to evaluate together
        final boolean[] updateFitness,  // should this individuals' fitness be updated?
        final boolean countVictoriesOnly,
        int[] subpops,
        final int threadnum)
        {
	if( ind.length != 2 || updateFitness.length != 2 )
            state.output.fatal( "The InternalSumProblem evaluates only two individuals at a time." );

        if( ! ( ind[0] instanceof IntegerVectorIndividual ) )
            state.output.fatal( "The individuals in the InternalSumProblem should be FloatVectorIndividuals." );

        if( ! ( ind[1] instanceof IntegerVectorIndividual ) )
            state.output.fatal( "The individuals in the InternalSumProblem should be FloatVectorIndividuals." );
        
        IntegerVectorIndividual tempMe, tempOther;

        // calculate the function value for the first individual
        tempMe = (IntegerVectorIndividual)ind[0];
	tempOther = (IntegerVectorIndividual)ind[1];
	
	double MyScore, OtherScore;
	MyScore = OtherScore = 0;

        //for( int i = 0 ; i < temp.genome.length ; i++ ) {
	
	  if ((Math.abs(tempMe.genome[0] - tempOther.genome[0]) > Math.abs(tempMe.genome[1] - tempOther.genome[1])) && (tempMe.genome[1] > tempOther.genome[1])) 		  { 
		//Adding noise constraints
                if (r.nextDouble() <=  NOISE_INTENSITY) {
			MyScore = 0;
			OtherScore = 1;
		}
		else { //Without Noisy
          		MyScore = 1; //Win
			OtherScore = 0; //Loss
		}
	  }	
          else if ((Math.abs(tempMe.genome[1] - tempOther.genome[1]) > Math.abs(tempMe.genome[0] - tempOther.genome[0])) && (tempMe.genome[0] > tempOther.genome[0])) 	  {
		if (r.nextDouble() <=  NOISE_INTENSITY) {
			MyScore = 0;
			OtherScore = 1;
		}
		else {
			MyScore = 1;
			OtherScore = 0;
		}
	   }
	  else {
		if (r.nextDouble() <=  NOISE_INTENSITY) {
			MyScore = 1;
			OtherScore = 0;
		}
		else {
			MyScore = 0;
			OtherScore = 1;
		}

	   }
        //}
	count++;
	//int hash = (Arrays.hashCode( tempMe.genome  ) & 0x7FFFFFFF) % 100; 
        //System.out.println("MyGenotypeHash : " + hash +  " MyGenotype: " + tempMe.genome[0] + "  " +tempMe.genome[1] + " , MyScore : " +MyScore);

	//hash = (Arrays.hashCode( tempOther.genome  ) & 0x7FFFFFFF) % 100; 
        //System.out.println("MyGenotypeHash : " + hash +  " MyGenotype: " + tempOther.genome[0] + "  " +tempOther.genome[1] + " , OtherScore : " +OtherScore);

        if( updateFitness[0] )
            {
	    
            SimpleFitness fit = ((SimpleFitness)(ind[0].fitness));
            fit.trials.add(new Double(MyScore));
                        
            // set the fitness because if we're doing Single Elimination Tournament, the tournament
            // needs to know who won this time around.  Don't bother declaring the ideal here.
            fit.setFitness(state, MyScore, false);
	    //System.out.println("Fitness first in evaluate:" +fit.fitness());
            }

        if( updateFitness[1] )
            {
	    
            SimpleFitness fit = ((SimpleFitness)(ind[1].fitness));
            fit.trials.add(new Double(OtherScore));

            // set the fitness because if we're doing Single Elimination Tournament, the tournament
            // needs to know who won this time around.
            fit.setFitness(state, OtherScore, false);
	    //System.out.println("Fitness second in evaluate:" +fit.fitness());
            }
        }

    }





