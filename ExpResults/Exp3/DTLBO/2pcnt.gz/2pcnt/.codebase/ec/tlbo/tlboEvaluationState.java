package ec.tlbo;
import ec.*;
import ec.simple.*;
import ec.vector.*;

import java.util.ArrayList;
import java.util.Random;

import ec.util.*;
/**
*
*  The evaluation state performs teacher and learner evaluation in a single generation except for the first
*  generation where initial evaluation is also performed.
* 
 */
public class tlboEvaluationState extends SimpleEvolutionState 
{
	private tlboBreeder breeder;
	private MersenneTwisterFast mtf;
	private boolean oneTimeEval = false;
    public static final String DIVERSITY_RATIO = "d-ratio";   
    double diversityRatio;
  
    	
	public void startFresh() {
		super.startFresh();	
		Parameter dRatio  = new Parameter(new String[]{"state","d-ratio"});  		
		diversityRatio  = this.parameters.getDouble(dRatio, null);
		breeder = new tlboBreeder();
	}
	
	public int evolve()  {
		if (generation > 0) 
			output.message("Generation " + generation);
		int count = 0;
		
		while(count < 2) {
			statistics.preEvaluationStatistics(this);
			
			if (!oneTimeEval)  {// Initializtion
				evaluator.evaluatePopulation(this);
				oneTimeEval = true;
			}
									
			if (evaluator.runComplete(this) && quitOnRunComplete) {
				output.message("found ideal individual");
				return R_SUCCESS;
			}
	
			if (generation == numGenerations-1) {
				return R_FAILURE;
			}
	
			if(count == 1) {
			statistics.prePreBreedingExchangeStatistics(this);
			population = exchanger.preBreedingExchangePopulation(this);
			statistics.postPreBreedingExchangeStatistics(this);
			statistics.preBreedingStatistics(this);
			}
			String exchangerWantsToShutdown = exchanger.runComplete(this);
			
			if (exchangerWantsToShutdown!=null) { 
				output.message(exchangerWantsToShutdown);                     
				return R_SUCCESS;
			}
	
			population = breeder.breedPopulation(this, count); // count = 0 : teacher phase, count = 1 : learner phase		
			evaluator.evaluatePopulation(this);
			
			if (count == 1) {
			statistics.postBreedingStatistics(this);
			statistics.prePostBreedingExchangeStatistics(this);
			population = exchanger.postBreedingExchangePopulation(this);
			statistics.postPostBreedingExchangeStatistics(this);
			}		
			count++;	
		}
		statistics.postEvaluationStatistics(this);
		

		ArrayList <Integer> popIndex = new ArrayList<Integer>();
		if (diversityRatio > 0) { // DTLBO				
			
			Random rand = new Random();
			Population currentPop = (Population) this.population;
			Subpopulation subpop = currentPop.subpops[0];
			double mu = getMean(subpop);
			double std = getStd(subpop, mu);
			
			//System.out.println("Mean : "+ mu + " Std : "+ getStd(subpop, mu));
			//int retries = 0;
			int len = subpop.individuals.length;
			double sizeRandomImmigrant =  len * diversityRatio;
			int counter = 0;
			int teacherIndex = breeder.getTeacherIndex(this, currentPop);
			double [] pg = ((DoubleVectorIndividual)subpop.individuals[teacherIndex]).genome;
								
			for (int x = 0; x < subpop.individuals.length; x++) {
				DoubleVectorIndividual ind = (DoubleVectorIndividual)subpop.individuals[x];		
				double fit = ((SimpleFitness)(ind.fitness)).fitness();
				double z = (fit - mu)/std;
				if (z <= 0) {
					double[] qtIndivGenome = getQuantumGenome(pg);
					((DoubleVectorIndividual)subpop.individuals[x]).setGenome(qtIndivGenome);
					counter++;
					//subpop.individuals[x] = (DoubleVectorIndividual)subpop.species.newIndividual(this, 0);
				}
				if (counter == sizeRandomImmigrant) break;
			}
		}
								
		generation++;
		return R_NOTDONE;	
	}
	private double [] getQuantumGenome(double [] pg) {
		Random rand = new Random();
		
		double [] tmp = new double[pg.length];
		double [] newGenome = new double[pg.length];
		double t = 0;
		for (int x = 0; x < pg.length; x++) { 
			tmp[x] = rand.nextGaussian();
			t += tmp[x] * tmp[x];		
		}
		double dist = Math.sqrt(t);
		
		double r = rand.nextDouble(); // r_cloud = 1
		for (int x = 0; x < pg.length; x++) {
			newGenome[x] = pg[x] + (r * tmp[x])/dist;
		}
		return newGenome;
	}
	private double getMean(Subpopulation subpop) {
		double sum = 0;
		for (int x = 0; x < subpop.individuals.length; x++) {
			DoubleVectorIndividual ind = (DoubleVectorIndividual)subpop.individuals[x];		
			sum += ((SimpleFitness)(ind.fitness)).fitness();
			
		}
		return sum/subpop.individuals.length;
	}
	private double getStd(Subpopulation subpop, double mu) {
		return Math.sqrt(getVariance(subpop, mu));
	}
	
	private double getVariance(Subpopulation subpop, double mu) {
		double tmp = 0;
		for (int x = 0; x < subpop.individuals.length; x++) {
			DoubleVectorIndividual ind = (DoubleVectorIndividual)subpop.individuals[x];		
			double dataPoint = ((SimpleFitness)(ind.fitness)).fitness();
			tmp += (dataPoint - mu) * (dataPoint - mu);
		}
		return tmp/(subpop.individuals.length - 1);
	}
}
