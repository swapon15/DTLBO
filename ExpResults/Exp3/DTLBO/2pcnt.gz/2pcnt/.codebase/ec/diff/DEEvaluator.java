package ec.diff;
import ec.*;
import ec.vector.*;
import ec.simple.*;
import ec.de.*;
import ec.tlbo.*;

public class DEEvaluator extends SimpleEvaluator
{
	
	boolean firstTimeOnly = false;
	public void evaluatePopulation(EvolutionState state) {
		super.evaluatePopulation(state);

		if( state.breeder instanceof DEBreeder ) {
			Population previousPopulation = ((DEBreeder)(state.breeder)).previousPopulation; 	
			int environmentID = tlboProblem.environmentID;
			
			if( previousPopulation != null ) {				
				for( int i = 0 ; i < previousPopulation.subpops.length ; i++ ) {
					
					if ((environmentID % 2 == 1) && !firstTimeOnly) {
						previousPopulation = state.population;
						firstTimeOnly = true;
					}
					else if ((environmentID % 2 == 0) && firstTimeOnly) {
						previousPopulation = state.population;
						firstTimeOnly = false;
					}
					
					for( int j = 0 ; j < state.population.subpops[i].individuals.length ; j++ )
						if( previousPopulation.subpops[i].individuals[j].fitness.betterThan( state.population.subpops[i].individuals[j].fitness ) )
							state.population.subpops[i].individuals[j] = previousPopulation.subpops[i].individuals[j];
					}
			}
		}
		else state.output.fatal("DEEvaluator requires DEBreeder to be the breeder.");
	}
}
